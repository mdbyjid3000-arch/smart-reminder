# SMART REMINDER
Created by: **Sujon Howlader** · Version 1.0

Notes, calendar, reminders, alarms, to-do list, message reminders, global search,
backup/restore, Bengali + English, PIN lock. 100% offline, all data stays on the phone.
Kotlin · Jetpack Compose (Material 3) · Room · AlarmManager.

---

## ফোন দিয়ে APK বানানোর ধাপ (কম্পিউটার লাগবে না)

আপনার কাছে দুটি ফাইল আছে: `SmartReminder.zip` এবং `build.yml`। এই দুটি দিয়েই কাজ হবে।

### ১. GitHub অ্যাকাউন্ট খুলুন (ফ্রি)
1. ফোনের ব্রাউজারে `github.com` খুলুন → **Sign up**।
2. আপনার ইমেইল দিয়ে অ্যাকাউন্ট খুলুন, ইমেইলে আসা কোড দিয়ে ভেরিফাই করুন।

### ২. নতুন রিপোজিটরি বানান
1. উপরে ডানে **+** → **New repository**।
2. নাম লিখুন: `smart-reminder`
3. **Public** বেছে নিন → **Create repository**।

### ৩. ZIP ফাইল আপলোড করুন
1. রিপোজিটরির পাতায় **Add file → Upload files**।
2. `SmartReminder.zip` বেছে নিন (ZIP খুলবেন না, যেমন আছে তেমনই দিন)।
3. আপলোড শেষ হলে নিচে **Commit changes** চাপুন।

### ৪. বিল্ড ফাইল যোগ করুন
1. **Add file → Create new file**।
2. ফাইলের নামের ঘরে হুবহু লিখুন: `.github/workflows/build.yml`
   (`/` লিখলে ফোল্ডার নিজে তৈরি হয়ে যায়)
3. নিচের বড় ঘরে `build.yml` ফাইলের পুরো লেখা কপি করে পেস্ট করুন।
4. **Commit changes** চাপুন।

### ৫. অপেক্ষা করুন (৫–১০ মিনিট)
1. উপরে **Actions** ট্যাব খুলুন।
2. "Build Smart Reminder APK" চলছে দেখাবে (হলুদ গোল)। সবুজ ✓ হলে বানানো শেষ।

### ৬. APK নামান ও ইনস্টল করুন
1. রিপোজিটরির মূল পাতায় **Releases** (ডান পাশে বা নিচে) চাপুন।
2. সর্বশেষ "Smart Reminder APK" খুলুন → **SmartReminder.apk** চাপুন, ডাউনলোড হবে।
3. ডাউনলোড হওয়া ফাইল খুলুন। ফোন "unknown source" জিজ্ঞেস করলে **Settings → Allow** দিন।
4. "Play Protect" সতর্কতা এলে **Install anyway** চাপুন (অ্যাপটি Play Store-এর নয় বলে আসে)।

### ৭. প্রথমবার খোলার পর
- নোটিফিকেশনের অনুমতি দিন।
- **Settings → Notifications** থেকে "Allow" চেপে এক্সাক্ট অ্যালার্মের অনুমতি দিন।
- **Settings → Battery settings** থেকে অ্যাপটিকে ব্যাটারি সীমা থেকে ছাড় দিন, যাতে রিমাইন্ডার ঠিক সময়ে বাজে।

### কিছু ভুল হলে
Actions-এ লাল ✗ দেখালে ওই রান খুলুন, লাল লেখাটির স্ক্রিনশট বা কপি করা লেখা আমাকে পাঠান। আমি ঠিক করে নতুন ZIP দেব।
নতুন ZIP পেলে আগের ZIP ডিলিট করে (ফাইলে ক্লিক → ডাস্টবিন আইকন) নতুনটি আপলোড করলেই আবার APK তৈরি হবে।
একই সাইনিং কী ব্যবহার হয়, তাই নতুন APK আগেরটির ওপর ইনস্টল করলে ডাটা মুছবে না।

---

## English summary
1. Create a free GitHub account and a new public repository.
2. Upload `SmartReminder.zip` (do not unzip).
3. Create the file `.github/workflows/build.yml` and paste the provided workflow.
4. Open **Actions**, wait for the green tick (~5–10 min).
5. Open **Releases**, download `SmartReminder.apk`, install it.

Local build with Android Studio: open the `SmartReminder` folder, let Gradle sync, run the `app` module.
Command line: `gradle assembleDebug` (Gradle 8.9, JDK 17) → `app/build/outputs/apk/debug/app-debug.apk`.

## Project layout
- `app/src/main/java/com/sujon/smartreminder/data` – Room database, backup/restore
- `.../notify` – exact-alarm scheduler, notifications, boot receiver
- `.../ui` – all Compose screens (Home, Notes, Calendar, Reminders, Tasks, Alarms, Search, Settings, About, Lock)
- `app/src/main/res` – English/Bengali strings, icons, built-in notification sounds
