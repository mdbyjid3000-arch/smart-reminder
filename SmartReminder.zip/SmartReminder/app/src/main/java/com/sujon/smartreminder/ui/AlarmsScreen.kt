package com.sujon.smartreminder.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.sujon.smartreminder.AppViewModel
import com.sujon.smartreminder.R
import com.sujon.smartreminder.data.AlarmItem
import com.sujon.smartreminder.util.T

@Composable
private fun daysText(days: Int): String {
    if (days == 0) return stringResource(R.string.once)
    if (days == 127) return stringResource(R.string.every_day)
    return T.weekOrder().filter { (days and (1 shl it)) != 0 }.joinToString(", ") { T.weekdayShort(it) }
}

@Composable
fun AlarmsScreen(vm: AppViewModel, nav: NavController) {
    val alarms by vm.alarms.collectAsStateWithLifecycle()
    var dialog by remember { mutableStateOf<AlarmItem?>(null) }

    Scaffold(
        topBar = { SubTopBar(stringResource(R.string.alarms), onBack = { nav.popBackStack() }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { dialog = AlarmItem(hour = 7, minute = 0) }) {
                Icon(Icons.Rounded.Add, stringResource(R.string.add_alarm))
            }
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
        ) {
            Box(Modifier.padding(horizontal = 16.dp)) { PermissionBanners() }
            if (alarms.isEmpty()) {
                EmptyState(Icons.Rounded.Alarm, stringResource(R.string.no_alarms))
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(alarms, key = { it.id }) { a ->
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (a.enabled) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { dialog = a }
                        ) {
                            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        T.hm(a.hour, a.minute),
                                        fontSize = 34.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        (if (a.label.isNotBlank()) a.label + " · " else "") + daysText(a.days),
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                Switch(checked = a.enabled, onCheckedChange = { vm.saveAlarm(a.copy(enabled = it)) })
                            }
                        }
                    }
                }
            }
        }
    }

    dialog?.let { a ->
        AlarmDialog(
            alarm = a,
            onSave = {
                vm.saveAlarm(it)
                dialog = null
            },
            onDelete = if (a.id != 0L) {
                {
                    vm.deleteAlarm(a)
                    dialog = null
                }
            } else null,
            onDismiss = { dialog = null }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AlarmDialog(
    alarm: AlarmItem,
    onSave: (AlarmItem) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    val state = rememberTimePickerState(initialHour = alarm.hour, initialMinute = alarm.minute)
    var label by remember { mutableStateOf(alarm.label) }
    var days by remember { mutableIntStateOf(alarm.days) }
    var sound by remember { mutableStateOf(alarm.sound) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(if (onDelete == null) R.string.add_alarm else R.string.edit_alarm)) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                TimePicker(state = state)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = label, onValueChange = { label = it },
                    label = { Text(stringResource(R.string.label)) },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Column(Modifier.fillMaxWidth()) {
                    FieldLabel(stringResource(R.string.repeat))
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        T.weekOrder().forEach { dow ->
                            FilterChip(
                                selected = (days and (1 shl dow)) != 0,
                                onClick = { days = days xor (1 shl dow) },
                                label = { Text(T.weekdayShort(dow)) }
                            )
                        }
                    }
                    Text(
                        daysText(days),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    FieldLabel(stringResource(R.string.sound))
                    SoundPicker(sound) { sound = it }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    alarm.copy(
                        hour = state.hour, minute = state.minute, label = label.trim(),
                        days = days, sound = sound, enabled = true
                    )
                )
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
            }
        }
    )
}
