package com.sujon.smartreminder

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.sujon.smartreminder.notify.Scheduler
import com.sujon.smartreminder.util.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmartApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setDefaultNightMode(
            when (Prefs.get(this).theme) {
                1 -> AppCompatDelegate.MODE_NIGHT_NO
                2 -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
        // Make sure every reminder / alarm is scheduled (cheap and safe to repeat).
        CoroutineScope(Dispatchers.IO).launch {
            try {
                Scheduler.rescheduleAll(this@SmartApp)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
