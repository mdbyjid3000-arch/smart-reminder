package com.sujon.smartreminder.util

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

class Prefs private constructor(ctx: Context) {
    private val sp = ctx.getSharedPreferences("smart_prefs", Context.MODE_PRIVATE)

    /** 0 = follow system, 1 = light, 2 = dark */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit().putInt("theme", v).apply()

    /** "" = follow system, otherwise "en" or "bn" */
    var lang: String
        get() = sp.getString("lang", "") ?: ""
        set(v) = sp.edit().putString("lang", v).apply()

    var snooze: Int
        get() = sp.getInt("snooze", 10)
        set(v) = sp.edit().putInt("snooze", v).apply()

    var pinHash: String
        get() = sp.getString("pin", "") ?: ""
        set(v) = sp.edit().putString("pin", v).apply()

    var secure: Boolean
        get() = sp.getBoolean("secure", false)
        set(v) = sp.edit().putBoolean("secure", v).apply()

    companion object {
        fun get(ctx: Context) = Prefs(ctx.applicationContext)
    }
}

/** Temporary flags shared between the UI and the activity. */
object AppFlags {
    /** Set before opening a system picker so the PIN lock does not trigger on return. */
    @Volatile
    var skipLock = false
}

object Lang {
    /** A context that uses the language chosen in the app (used for notifications). */
    fun localized(ctx: Context): Context {
        val l = Prefs.get(ctx).lang
        if (l.isEmpty()) return ctx
        val cfg = Configuration(ctx.resources.configuration)
        cfg.setLocale(Locale.forLanguageTag(l))
        return ctx.createConfigurationContext(cfg)
    }
}
