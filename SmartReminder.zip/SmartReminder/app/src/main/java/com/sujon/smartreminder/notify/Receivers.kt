package com.sujon.smartreminder.notify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import com.sujon.smartreminder.data.AppDb
import com.sujon.smartreminder.util.Prefs
import com.sujon.smartreminder.util.T
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

private fun BroadcastReceiver.async(block: suspend () -> Unit) {
    val pending = goAsync()
    CoroutineScope(Dispatchers.IO).launch {
        try {
            block()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            pending.finish()
        }
    }
}

/** Fires when a scheduled reminder / alarm / event is due. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val type = intent.getIntExtra("type", 0)
        val id = intent.getLongExtra("id", 0)
        val snooze = intent.getBooleanExtra("snooze", false)
        val app = context.applicationContext

        async {
            val db = AppDb.get(app)
            when (type) {
                Scheduler.T_REMINDER -> {
                    val r = db.reminders().get(id) ?: return@async
                    if (r.completed) return@async
                    Notifier.showReminder(app, r)
                    if (!snooze && r.repeat != 0) {
                        val next = T.nextRepeat(r.timeMillis, r.repeat)
                        db.reminders().upsert(r.copy(timeMillis = next))
                        Scheduler.scheduleAt(app, Scheduler.T_REMINDER, id, next)
                    }
                }
                Scheduler.T_ALARM -> {
                    val a = db.alarms().get(id) ?: return@async
                    if (!a.enabled) return@async
                    Notifier.showAlarm(app, a)
                    if (!snooze) {
                        if (a.days == 0) {
                            db.alarms().upsert(a.copy(enabled = false))
                        } else {
                            Scheduler.scheduleAt(
                                app, Scheduler.T_ALARM, id,
                                T.nextAlarm(a.hour, a.minute, a.days)
                            )
                        }
                    }
                }
                Scheduler.T_EVENT -> {
                    val e = db.events().get(id) ?: return@async
                    Notifier.showEvent(app, e)
                }
            }
        }
    }
}

/** Handles the Snooze / Done / Dismiss buttons on notifications. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val type = intent.getIntExtra("type", 0)
        val id = intent.getLongExtra("id", 0)
        val app = context.applicationContext

        NotificationManagerCompat.from(app).cancel(Notifier.nid(type, id))

        when (intent.action) {
            Notifier.ACT_SNOOZE -> {
                val at = T.now() + Prefs.get(app).snooze * T.MIN
                Scheduler.scheduleAt(app, type, id, at, snooze = true)
            }
            Notifier.ACT_DONE -> async {
                if (type == Scheduler.T_REMINDER) {
                    val dao = AppDb.get(app).reminders()
                    val r = dao.get(id) ?: return@async
                    // Repeating reminders were already moved to their next date.
                    if (r.repeat == 0) dao.upsert(r.copy(completed = true))
                }
            }
            else -> Unit
        }
    }
}

/** Restores every schedule after reboot, app update, time or time-zone change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        async { Scheduler.rescheduleAll(app) }
    }
}
