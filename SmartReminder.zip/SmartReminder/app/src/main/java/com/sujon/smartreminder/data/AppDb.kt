package com.sujon.smartreminder.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [Note::class, Reminder::class, AlarmItem::class, TaskItem::class, EventItem::class],
    version = 1,
    exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun notes(): NoteDao
    abstract fun reminders(): ReminderDao
    abstract fun alarms(): AlarmDao
    abstract fun tasks(): TaskDao
    abstract fun events(): EventDao

    companion object {
        @Volatile
        private var instance: AppDb? = null

        fun get(ctx: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                ctx.applicationContext, AppDb::class.java, "smart_reminder.db"
            ).build().also { instance = it }
        }
    }
}
