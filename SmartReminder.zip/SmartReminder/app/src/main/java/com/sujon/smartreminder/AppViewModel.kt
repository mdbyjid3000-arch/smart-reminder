package com.sujon.smartreminder

import android.app.Application
import android.net.Uri
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sujon.smartreminder.data.AlarmItem
import com.sujon.smartreminder.data.AppDb
import com.sujon.smartreminder.data.Backup
import com.sujon.smartreminder.data.EventItem
import com.sujon.smartreminder.data.Note
import com.sujon.smartreminder.data.Reminder
import com.sujon.smartreminder.data.TaskItem
import com.sujon.smartreminder.data.triggerAt
import com.sujon.smartreminder.notify.Scheduler
import com.sujon.smartreminder.util.Prefs
import com.sujon.smartreminder.util.T
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.security.MessageDigest
import java.util.Locale

class AppViewModel(private val app: Application) : AndroidViewModel(app) {

    private val db = AppDb.get(app)
    private val prefs = Prefs.get(app)

    val notes = db.notes().observe()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<Note>())
    val reminders = db.reminders().observe()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<Reminder>())
    val alarms = db.alarms().observe()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<AlarmItem>())
    val tasks = db.tasks().observe()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<TaskItem>())
    val events = db.events().observe()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<EventItem>())

    // ---------- settings ----------
    var theme by mutableIntStateOf(prefs.theme)
        private set
    var lang by mutableStateOf(initialLang())
        private set
    var snooze by mutableIntStateOf(prefs.snooze)
        private set
    var hasPin by mutableStateOf(prefs.pinHash.isNotEmpty())
        private set
    var secure by mutableStateOf(prefs.secure)
        private set
    var locked by mutableStateOf(prefs.pinHash.isNotEmpty())
        private set

    /** One-shot messages (string resource ids) shown as toasts. */
    val messages = Channel<Int>(Channel.BUFFERED)

    private fun initialLang(): String {
        val saved = prefs.lang
        if (saved.isNotEmpty()) return saved
        return if (Locale.getDefault().language == "bn") "bn" else "en"
    }

    fun setTheme(v: Int) {
        prefs.theme = v
        theme = v
        AppCompatDelegate.setDefaultNightMode(
            when (v) {
                1 -> AppCompatDelegate.MODE_NIGHT_NO
                2 -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }

    fun setLang(l: String) {
        prefs.lang = l
        lang = l
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(l))
    }

    fun setSnooze(m: Int) {
        prefs.snooze = m
        snooze = m
    }

    fun setSecure(v: Boolean) {
        prefs.secure = v
        secure = v
    }

    // ---------- privacy / PIN ----------
    private fun hash(pin: String): String =
        MessageDigest.getInstance("SHA-256").digest(("sr_salt:$pin").toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun setPin(pin: String) {
        prefs.pinHash = hash(pin)
        hasPin = true
    }

    fun checkPin(pin: String): Boolean = hash(pin) == prefs.pinHash

    fun removePin() {
        prefs.pinHash = ""
        hasPin = false
        locked = false
    }

    fun unlock(pin: String): Boolean {
        if (checkPin(pin)) {
            locked = false
            return true
        }
        return false
    }

    fun lockNow() {
        if (hasPin) locked = true
    }

    // ---------- notes ----------
    fun saveNote(n: Note) {
        viewModelScope.launch(Dispatchers.IO) {
            db.notes().upsert(n.copy(updatedAt = T.now()))
        }
    }

    fun deleteNote(n: Note) {
        viewModelScope.launch(Dispatchers.IO) {
            if (n.audioPath.isNotEmpty()) File(n.audioPath).delete()
            db.notes().delete(n.id)
        }
    }

    // ---------- reminders ----------
    fun saveReminder(r: Reminder) {
        viewModelScope.launch(Dispatchers.IO) {
            var t = r.timeMillis
            if (r.repeat != 0 && t <= T.now()) t = T.nextRepeat(t, r.repeat)
            val item = r.copy(timeMillis = t)
            val id = db.reminders().upsert(item)
            val key = if (item.id != 0L) item.id else id
            if (!item.completed && item.timeMillis > T.now()) {
                Scheduler.scheduleAt(app, Scheduler.T_REMINDER, key, item.timeMillis)
            } else {
                Scheduler.cancel(app, Scheduler.T_REMINDER, key)
            }
        }
    }

    fun toggleReminder(r: Reminder) {
        if (!r.completed && r.repeat != 0) {
            // A repeating reminder: finish this occurrence and move to the next one.
            saveReminder(r.copy(timeMillis = T.nextRepeat(r.timeMillis, r.repeat)))
        } else {
            saveReminder(r.copy(completed = !r.completed))
        }
    }

    fun snoozeReminder(r: Reminder) {
        saveReminder(r.copy(timeMillis = T.now() + snooze * T.MIN, completed = false))
    }

    fun deleteReminder(r: Reminder) {
        viewModelScope.launch(Dispatchers.IO) {
            Scheduler.cancel(app, Scheduler.T_REMINDER, r.id)
            db.reminders().delete(r.id)
        }
    }

    // ---------- alarms ----------
    fun saveAlarm(a: AlarmItem) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = db.alarms().upsert(a)
            val key = if (a.id != 0L) a.id else id
            if (a.enabled) {
                Scheduler.scheduleAt(
                    app, Scheduler.T_ALARM, key, T.nextAlarm(a.hour, a.minute, a.days)
                )
            } else {
                Scheduler.cancel(app, Scheduler.T_ALARM, key)
            }
        }
    }

    fun deleteAlarm(a: AlarmItem) {
        viewModelScope.launch(Dispatchers.IO) {
            Scheduler.cancel(app, Scheduler.T_ALARM, a.id)
            db.alarms().delete(a.id)
        }
    }

    // ---------- tasks ----------
    fun saveTask(t: TaskItem) {
        viewModelScope.launch(Dispatchers.IO) { db.tasks().upsert(t) }
    }

    fun toggleTask(t: TaskItem) {
        saveTask(t.copy(done = !t.done, doneAt = if (!t.done) T.now() else 0))
    }

    fun deleteTask(t: TaskItem) {
        viewModelScope.launch(Dispatchers.IO) { db.tasks().delete(t.id) }
    }

    // ---------- events ----------
    fun saveEvent(e: EventItem) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = db.events().upsert(e)
            val key = if (e.id != 0L) e.id else id
            val at = e.triggerAt()
            if (e.remindMinutes >= 0 && at > T.now()) {
                Scheduler.scheduleAt(app, Scheduler.T_EVENT, key, at)
            } else {
                Scheduler.cancel(app, Scheduler.T_EVENT, key)
            }
        }
    }

    fun deleteEvent(e: EventItem) {
        viewModelScope.launch(Dispatchers.IO) {
            Scheduler.cancel(app, Scheduler.T_EVENT, e.id)
            db.events().delete(e.id)
        }
    }

    // ---------- backup ----------
    fun exportBackup(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val out = app.contentResolver.openOutputStream(uri)
                    ?: throw IllegalStateException("No output stream")
                out.use { Backup.write(db, it) }
                messages.send(R.string.backup_done)
            } catch (e: Exception) {
                messages.send(R.string.backup_failed)
            }
        }
    }

    fun importBackup(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val input = app.contentResolver.openInputStream(uri)
                    ?: throw IllegalStateException("No input stream")
                Scheduler.cancelAll(app)
                input.use { Backup.read(db, it) }
                Scheduler.rescheduleAll(app)
                messages.send(R.string.restore_done)
            } catch (e: Exception) {
                Scheduler.rescheduleAll(app)
                messages.send(R.string.restore_failed)
            }
        }
    }
}
