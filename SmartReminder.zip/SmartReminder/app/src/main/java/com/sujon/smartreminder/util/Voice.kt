package com.sujon.smartreminder.util

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import java.io.File

/** Very small wrapper around MediaRecorder / MediaPlayer for voice notes. */
class VoiceRecorder(private val ctx: Context) {
    private var recorder: MediaRecorder? = null
    var file: File? = null
        private set

    fun start(): Boolean {
        return try {
            val f = File(ctx.filesDir, "voice_${System.currentTimeMillis()}.m4a")
            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(96_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            file = f
            true
        } catch (e: Exception) {
            release()
            false
        }
    }

    /** Returns the recorded file, or null if the recording failed. */
    fun stop(): File? {
        val r = recorder ?: return null
        val f = file
        recorder = null
        return try {
            r.stop()
            r.release()
            f
        } catch (e: Exception) {
            try {
                r.release()
            } catch (_: Exception) {
            }
            f?.delete()
            null
        }
    }

    fun release() {
        try {
            recorder?.release()
        } catch (_: Exception) {
        }
        recorder = null
    }
}

class VoicePlayer {
    private var player: MediaPlayer? = null

    fun play(path: String, onComplete: () -> Unit): Boolean {
        stop()
        return try {
            val p = MediaPlayer()
            p.setDataSource(path)
            p.setOnCompletionListener {
                onComplete()
                stop()
            }
            p.prepare()
            p.start()
            player = p
            true
        } catch (e: Exception) {
            stop()
            false
        }
    }

    fun stop() {
        try {
            player?.release()
        } catch (_: Exception) {
        }
        player = null
    }
}
