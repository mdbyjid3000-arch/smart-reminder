package com.sujon.smartreminder.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.sujon.smartreminder.MainActivity
import com.sujon.smartreminder.R
import com.sujon.smartreminder.data.AlarmItem
import com.sujon.smartreminder.data.EventItem
import com.sujon.smartreminder.data.Reminder
import com.sujon.smartreminder.util.Lang
import com.sujon.smartreminder.util.T

object Notifier {
    const val ACT_DONE = "com.sujon.smartreminder.DONE"
    const val ACT_SNOOZE = "com.sujon.smartreminder.SNOOZE"
    const val ACT_DISMISS = "com.sujon.smartreminder.DISMISS"

    private val BUILT_IN = mapOf(
        "chime" to R.raw.chime,
        "bell" to R.raw.bell,
        "beep" to R.raw.beep,
        "pulse" to R.raw.pulse
    )

    fun nid(type: Int, id: Long): Int = type * 100_000 + (id % 100_000).toInt()

    fun canNotify(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    fun soundUri(ctx: Context, sound: String, alarm: Boolean): Uri? {
        if (sound.isEmpty() || sound == "default") {
            return RingtoneManager.getDefaultUri(
                if (alarm) RingtoneManager.TYPE_ALARM else RingtoneManager.TYPE_NOTIFICATION
            )
        }
        val res = BUILT_IN[sound]
        if (res != null) return Uri.parse("android.resource://${ctx.packageName}/$res")
        return Uri.parse(sound)
    }

    private fun soundLabel(ctx: Context, sound: String): String = when (sound) {
        "", "default" -> ctx.getString(R.string.sound_default)
        "chime" -> ctx.getString(R.string.sound_chime)
        "bell" -> ctx.getString(R.string.sound_bell)
        "beep" -> ctx.getString(R.string.sound_beep)
        "pulse" -> ctx.getString(R.string.sound_pulse)
        else -> ctx.getString(R.string.sound_custom)
    }

    /** Android fixes a channel's sound after creation, so each sound gets its own channel. */
    fun channel(ctx: Context, sound: String, alarm: Boolean): String {
        val id = (if (alarm) "alarm_" else "rem_") + sound.hashCode()
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(id) == null) {
            val name = ctx.getString(if (alarm) R.string.channel_alarms else R.string.channel_reminders) +
                " – " + soundLabel(ctx, sound)
            val ch = NotificationChannel(id, name, NotificationManager.IMPORTANCE_HIGH)
            val attrs = AudioAttributes.Builder()
                .setUsage(if (alarm) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            ch.setSound(soundUri(ctx, sound, alarm), attrs)
            ch.enableVibration(true)
            ch.vibrationPattern = longArrayOf(0, 400, 200, 400)
            ch.lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
        return id
    }

    private fun openApp(ctx: Context, type: Int, route: String): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("route", route)
        return PendingIntent.getActivity(
            ctx, type, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun actionPi(ctx: Context, action: String, type: Int, id: Long): PendingIntent {
        val i = Intent(ctx, ActionReceiver::class.java)
            .setAction(action)
            .setData(Uri.parse("smartreminder://action/$action/$type/$id"))
            .putExtra("type", type)
            .putExtra("id", id)
        return PendingIntent.getBroadcast(
            ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun builder(
        ctx: Context, channel: String, title: String, text: String, type: Int, route: String
    ): NotificationCompat.Builder =
        NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_notif)
            .setColor(0xFF5B4BDB.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx, type, route))

    private fun post(ctx: Context, id: Int, n: android.app.Notification) {
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (e: SecurityException) {
            // Notification permission was revoked – nothing we can do.
        }
    }

    fun showReminder(base: Context, r: Reminder) {
        val ctx = Lang.localized(base)
        if (!canNotify(ctx)) return
        val ch = channel(ctx, r.sound, false)
        val title = r.title.ifBlank { ctx.getString(R.string.reminder) }
        val text = if (r.isMessage) {
            ctx.getString(
                R.string.msg_notif_text,
                r.phone.ifBlank { "—" },
                r.message.ifBlank { r.notes }
            )
        } else r.notes.ifBlank { T.time(r.timeMillis) }

        val b = builder(ctx, ch, title, text, Scheduler.T_REMINDER, "reminders")
            .setCategory(NotificationCompat.CATEGORY_REMINDER)

        if (r.isMessage) {
            // The message is never sent automatically – the user only gets shortcuts to
            // open a messaging app with the text prepared.
            val sms = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(r.phone)))
                .putExtra("sms_body", r.message)
            val smsPi = PendingIntent.getActivity(
                ctx, Scheduler.T_REMINDER * 7, sms,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, r.message)
            val sharePi = PendingIntent.getActivity(
                ctx, Scheduler.T_REMINDER * 11, Intent.createChooser(send, title),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            b.addAction(R.drawable.ic_notif, ctx.getString(R.string.open_messages), smsPi)
            b.addAction(R.drawable.ic_notif, ctx.getString(R.string.other_app), sharePi)
            b.addAction(
                R.drawable.ic_notif, ctx.getString(R.string.snooze),
                actionPi(ctx, Notifier.ACT_SNOOZE, Scheduler.T_REMINDER, r.id)
            )
        } else {
            b.addAction(
                R.drawable.ic_notif, ctx.getString(R.string.snooze),
                actionPi(ctx, ACT_SNOOZE, Scheduler.T_REMINDER, r.id)
            )
            b.addAction(
                R.drawable.ic_notif, ctx.getString(R.string.mark_done),
                actionPi(ctx, ACT_DONE, Scheduler.T_REMINDER, r.id)
            )
        }
        post(ctx, nid(Scheduler.T_REMINDER, r.id), b.build())
    }

    fun showAlarm(base: Context, a: AlarmItem) {
        val ctx = Lang.localized(base)
        if (!canNotify(ctx)) return
        val ch = channel(ctx, a.sound, true)
        val title = a.label.ifBlank { ctx.getString(R.string.alarm) }
        val b = builder(ctx, ch, title, T.hm(a.hour, a.minute), Scheduler.T_ALARM, "alarms")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setAutoCancel(false)
            .setTimeoutAfter(60_000)
            .addAction(
                R.drawable.ic_notif, ctx.getString(R.string.snooze),
                actionPi(ctx, ACT_SNOOZE, Scheduler.T_ALARM, a.id)
            )
            .addAction(
                R.drawable.ic_notif, ctx.getString(R.string.dismiss),
                actionPi(ctx, ACT_DISMISS, Scheduler.T_ALARM, a.id)
            )
        val n = b.build()
        // Keep the sound repeating until the alarm is dismissed (or times out).
        n.flags = n.flags or android.app.Notification.FLAG_INSISTENT
        post(ctx, nid(Scheduler.T_ALARM, a.id), n)
    }

    fun showEvent(base: Context, e: EventItem) {
        val ctx = Lang.localized(base)
        if (!canNotify(ctx)) return
        val ch = channel(ctx, "default", false)
        val whenText = if (e.allDay) T.date(e.startMillis) else T.full(e.startMillis)
        val text = if (e.description.isBlank()) whenText else whenText + "\n" + e.description
        val b = builder(
            ctx, ch, e.title.ifBlank { ctx.getString(R.string.event) }, text,
            Scheduler.T_EVENT, "calendar"
        ).setCategory(NotificationCompat.CATEGORY_EVENT)
        post(ctx, nid(Scheduler.T_EVENT, e.id), b.build())
    }
}
