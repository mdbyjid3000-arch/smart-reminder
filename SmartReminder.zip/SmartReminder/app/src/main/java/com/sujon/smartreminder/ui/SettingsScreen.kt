package com.sujon.smartreminder.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.sujon.smartreminder.AppViewModel
import com.sujon.smartreminder.R
import com.sujon.smartreminder.util.AppFlags
import com.sujon.smartreminder.util.Perms

private enum class PinMode { SET, CHANGE, REMOVE }

@Composable
fun SettingsScreen(vm: AppViewModel, nav: NavController, onSecureChanged: () -> Unit) {
    val ctx = LocalContext.current
    var pinMode by remember { mutableStateOf<PinMode?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) vm.exportBackup(uri) }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) vm.importBackup(uri) }

    val snoozeValues = listOf(5, 10, 15, 30)

    Scaffold(topBar = { SubTopBar(stringResource(R.string.settings), onBack = { nav.popBackStack() }) }) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            SectionHeader(stringResource(R.string.appearance))
            ChipRow(
                listOf(
                    stringResource(R.string.theme_system), stringResource(R.string.theme_light),
                    stringResource(R.string.theme_dark)
                ),
                vm.theme, { vm.setTheme(it) }
            )

            SectionHeader(stringResource(R.string.language))
            ChipRow(listOf("English", "বাংলা"), if (vm.lang == "bn") 1 else 0, { vm.setLang(if (it == 1) "bn" else "en") })

            SectionHeader(stringResource(R.string.notifications))
            PermissionBanners()
            Text(
                stringResource(R.string.battery_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            OutlinedButton(onClick = { Perms.openBatterySettings(ctx) }) {
                Text(stringResource(R.string.battery_button))
            }
            FieldLabel(stringResource(R.string.snooze_time))
            ChipRow(
                snoozeValues.map { stringResource(R.string.minutes_fmt, it) },
                snoozeValues.indexOf(vm.snooze).coerceAtLeast(0),
                { vm.setSnooze(snoozeValues[it]) }
            )

            SectionHeader(stringResource(R.string.privacy))
            Text(
                stringResource(R.string.privacy_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            if (vm.hasPin) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pinMode = PinMode.CHANGE }) { Text(stringResource(R.string.change_pin)) }
                    OutlinedButton(onClick = { pinMode = PinMode.REMOVE }) { Text(stringResource(R.string.remove_pin)) }
                }
            } else {
                Button(onClick = { pinMode = PinMode.SET }) { Text(stringResource(R.string.set_pin)) }
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.block_screenshots), style = MaterialTheme.typography.titleMedium)
                    Text(
                        stringResource(R.string.block_screenshots_hint),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = vm.secure, onCheckedChange = {
                    vm.setSecure(it)
                    onSecureChanged()
                })
            }

            SectionHeader(stringResource(R.string.backup_restore))
            Text(
                stringResource(R.string.backup_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    AppFlags.skipLock = true
                    exportLauncher.launch("smart_reminder_backup.json")
                }) { Text(stringResource(R.string.create_backup)) }
                OutlinedButton(onClick = {
                    AppFlags.skipLock = true
                    importLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream"))
                }) { Text(stringResource(R.string.restore_backup)) }
            }

            SectionHeader(stringResource(R.string.about))
            ListItem(
                leadingContent = { Icon(Icons.Rounded.Info, null) },
                headlineContent = { Text(stringResource(R.string.about_app)) },
                supportingContent = { Text(stringResource(R.string.about_version)) },
                modifier = Modifier.clickable { nav.navigate("about") }
            )
            Spacer(Modifier.height(32.dp))
        }
    }

    pinMode?.let { mode ->
        PinDialog(vm, mode) { pinMode = null }
    }
}

@Composable
private fun PinDialog(vm: AppViewModel, mode: PinMode, onClose: () -> Unit) {
    var current by remember { mutableStateOf("") }
    var new1 by remember { mutableStateOf("") }
    var new2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<Int?>(null) }

    @Composable
    fun pinField(value: String, label: Int, onChange: (String) -> Unit) {
        OutlinedTextField(
            value = value,
            onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) onChange(it) },
            label = { Text(stringResource(label)) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        )
    }

    AlertDialog(
        onDismissRequest = onClose,
        title = {
            Text(
                stringResource(
                    when (mode) {
                        PinMode.SET -> R.string.set_pin
                        PinMode.CHANGE -> R.string.change_pin
                        PinMode.REMOVE -> R.string.remove_pin
                    }
                )
            )
        },
        text = {
            Column {
                if (mode != PinMode.SET) pinField(current, R.string.current_pin) { current = it }
                if (mode != PinMode.REMOVE) {
                    pinField(new1, R.string.new_pin) { new1 = it }
                    pinField(new2, R.string.confirm_pin) { new2 = it }
                }
                error?.let {
                    Text(
                        stringResource(it),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (mode != PinMode.SET && !vm.checkPin(current)) {
                    error = R.string.wrong_pin
                } else if (mode == PinMode.REMOVE) {
                    vm.removePin()
                    onClose()
                } else if (new1.length < 4) {
                    error = R.string.pin_too_short
                } else if (new1 != new2) {
                    error = R.string.pin_mismatch
                } else {
                    vm.setPin(new1)
                    onClose()
                }
            }) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text(stringResource(R.string.cancel)) } }
    )
}
