package com.sujon.smartreminder.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Snooze
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.sujon.smartreminder.AppViewModel
import com.sujon.smartreminder.R
import com.sujon.smartreminder.data.Reminder
import com.sujon.smartreminder.util.T

@Composable
fun RemindersScreen(vm: AppViewModel, nav: NavController) {
    val reminders by vm.reminders.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) } // 0 upcoming, 1 completed
    var dialog by remember { mutableStateOf<Reminder?>(null) }
    var deleting by remember { mutableStateOf<Reminder?>(null) }

    val shown = reminders.filter { it.completed == (tab == 1) }

    fun newReminder(): Reminder {
        val t = T.withTime(T.now() + 3_600_000L, T.hour(T.now() + 3_600_000L), 0)
        return Reminder(timeMillis = t)
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                PermissionBanners()
                Spacer(Modifier.height(8.dp))
                ChipRow(
                    listOf(stringResource(R.string.upcoming), stringResource(R.string.completed)),
                    tab, { tab = it }
                )
            }
            if (shown.isEmpty()) {
                EmptyState(
                    Icons.Rounded.Notifications,
                    stringResource(if (tab == 0) R.string.no_reminders else R.string.no_completed)
                )
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(shown, key = { it.id }) { r ->
                        ReminderRow(
                            r,
                            onToggle = { vm.toggleReminder(r) },
                            onClick = { dialog = r },
                            trailing = {
                                if (!r.completed && r.repeat == 0) {
                                    IconButton(onClick = { vm.snoozeReminder(r) }) {
                                        Icon(Icons.Rounded.Snooze, stringResource(R.string.snooze))
                                    }
                                }
                                IconButton(onClick = { deleting = r }) {
                                    Icon(Icons.Rounded.Delete, stringResource(R.string.delete))
                                }
                            }
                        )
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { dialog = newReminder() },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) { Icon(Icons.Rounded.Add, stringResource(R.string.add_reminder)) }
    }

    dialog?.let { r ->
        ReminderDialog(
            reminder = r,
            onSave = {
                vm.saveReminder(it)
                dialog = null
            },
            onDismiss = { dialog = null }
        )
    }
    deleting?.let { r ->
        ConfirmDialog(
            text = stringResource(R.string.confirm_delete),
            onConfirm = {
                vm.deleteReminder(r)
                deleting = null
            },
            onDismiss = { deleting = null }
        )
    }
}

@Composable
private fun ReminderDialog(reminder: Reminder, onSave: (Reminder) -> Unit, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf(reminder.title) }
    var notes by remember { mutableStateOf(reminder.notes) }
    var time by remember { mutableLongStateOf(reminder.timeMillis) }
    var repeat by remember { mutableIntStateOf(reminder.repeat) }
    var sound by remember { mutableStateOf(reminder.sound) }
    var isMessage by remember { mutableStateOf(reminder.isMessage) }
    var phone by remember { mutableStateOf(reminder.phone) }
    var message by remember { mutableStateOf(reminder.message) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(stringResource(if (reminder.id == 0L) R.string.add_reminder else R.string.edit_reminder))
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text(stringResource(R.string.title)) },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = notes, onValueChange = { notes = it },
                    label = { Text(stringResource(R.string.description)) },
                    modifier = Modifier.fillMaxWidth()
                )
                FieldLabel(stringResource(R.string.date_time))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DateField(time, { time = it })
                    TimeField(time, { time = it })
                }
                FieldLabel(stringResource(R.string.repeat))
                ChipRow(repeatLabels(), repeat, { repeat = it })
                FieldLabel(stringResource(R.string.sound))
                SoundPicker(sound) { sound = it }

                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.message_reminder), style = MaterialTheme.typography.titleMedium)
                        Text(
                            stringResource(R.string.message_reminder_hint),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = isMessage, onCheckedChange = { isMessage = it })
                }
                if (isMessage) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = phone, onValueChange = { phone = it },
                        label = { Text(stringResource(R.string.phone_number)) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = message, onValueChange = { message = it },
                        label = { Text(stringResource(R.string.message_text)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank() || (isMessage && message.isNotBlank()),
                onClick = {
                    onSave(
                        reminder.copy(
                            title = title.trim(), notes = notes.trim(), timeMillis = time,
                            repeat = repeat, sound = sound, isMessage = isMessage,
                            phone = phone.trim(), message = message.trim()
                        )
                    )
                }
            ) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}
