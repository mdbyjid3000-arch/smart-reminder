package com.sujon.smartreminder.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.sujon.smartreminder.AppViewModel
import com.sujon.smartreminder.R
import com.sujon.smartreminder.data.EventItem
import com.sujon.smartreminder.util.T

private fun EventItem.onDay(day: Long): Boolean {
    val end = maxOf(endMillis, startMillis + 1)
    return startMillis < T.endOfDay(day) && end > day
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(vm: AppViewModel, nav: NavController) {
    val events by vm.events.collectAsStateWithLifecycle()
    var mode by remember { mutableIntStateOf(0) } // 0 month, 1 week, 2 day
    var anchor by remember { mutableLongStateOf(T.startOfDay(T.now())) }
    var dialog by remember { mutableStateOf<EventItem?>(null) }

    fun step(dir: Int) {
        anchor = when (mode) {
            0 -> T.addMonths(anchor, dir)
            1 -> T.addDays(anchor, 7 * dir)
            else -> T.addDays(anchor, dir)
        }
    }

    fun newEvent(): EventItem {
        val base = if (T.sameDay(anchor, T.now())) {
            T.withTime(anchor, T.hour(T.now()) + 1, 0)
        } else T.withTime(anchor, 9, 0)
        return EventItem(startMillis = base, endMillis = base + 3_600_000L)
    }

    val modeLabels = listOf(
        stringResource(R.string.month), stringResource(R.string.week), stringResource(R.string.day)
    )

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            SingleChoiceSegmentedButtonRow(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                modeLabels.forEachIndexed { i, label ->
                    SegmentedButton(
                        selected = mode == i,
                        onClick = { mode = i },
                        shape = SegmentedButtonDefaults.itemShape(index = i, count = modeLabels.size)
                    ) { Text(label) }
                }
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { step(-1) }) { Icon(Icons.Rounded.ChevronLeft, null) }
                val title = when (mode) {
                    0 -> T.monthTitle(anchor)
                    1 -> {
                        val ws = T.weekStart(anchor)
                        T.shortDay(ws) + " – " + T.shortDay(T.addDays(ws, 6))
                    }
                    else -> T.dayTitle(anchor)
                }
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { step(1) }) { Icon(Icons.Rounded.ChevronRight, null) }
                TextButton(onClick = { anchor = T.startOfDay(T.now()) }) {
                    Text(stringResource(R.string.today))
                }
            }

            AnimatedContent(
                targetState = mode,
                transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
                label = "calendar-mode"
            ) { m ->
                when (m) {
                    0 -> MonthView(events, anchor, { anchor = it }, { dialog = it })
                    1 -> WeekView(events, anchor, { anchor = it }, { dialog = it })
                    else -> DayView(events, anchor, { dialog = it })
                }
            }
        }
        FloatingActionButton(
            onClick = { dialog = newEvent() },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) { Icon(Icons.Rounded.Add, stringResource(R.string.add_event)) }
    }

    dialog?.let { ev ->
        EventDialog(
            event = ev,
            onSave = {
                vm.saveEvent(it)
                dialog = null
            },
            onDelete = if (ev.id != 0L) {
                {
                    vm.deleteEvent(ev)
                    dialog = null
                }
            } else null,
            onDismiss = { dialog = null }
        )
    }
}

@Composable
private fun DayEvents(events: List<EventItem>, day: Long, onEdit: (EventItem) -> Unit) {
    val list = events.filter { it.onDay(day) }
    if (list.isEmpty()) {
        EmptyCardText(stringResource(R.string.no_events_day))
    } else {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            list.forEach { e -> EventRow(e, onClick = { onEdit(e) }) }
        }
    }
}

@Composable
private fun MonthView(
    events: List<EventItem>, anchor: Long,
    onSelect: (Long) -> Unit, onEdit: (EventItem) -> Unit
) {
    val grid = T.monthGrid(anchor)
    val today = T.startOfDay(T.now())
    val upcoming = events.filter { it.startMillis >= T.now() }.take(5)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth()) {
                T.weekOrder().forEach { dow ->
                    Text(
                        T.weekdayShort(dow),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            AnimatedContent(
                targetState = T.monthTitle(anchor),
                transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
                label = "month"
            ) { _ ->
                Column {
                    grid.chunked(7).forEach { week ->
                        Row(Modifier.fillMaxWidth()) {
                            week.forEach { day ->
                                Box(
                                    Modifier
                                        .weight(1f)
                                        .height(50.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (day != null) {
                                        val selected = T.sameDay(day, anchor)
                                        val isToday = day == today
                                        val count = events.count { it.onDay(day) }
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier
                                                .clip(CircleShape)
                                                .clickable { onSelect(day) }
                                                .padding(horizontal = 4.dp)
                                        ) {
                                            Box(
                                                Modifier
                                                    .size(34.dp)
                                                    .clip(CircleShape)
                                                    .background(
                                                        if (selected) MaterialTheme.colorScheme.primary
                                                        else Color.Transparent
                                                    )
                                                    .then(
                                                        if (isToday && !selected) Modifier.border(
                                                            1.5.dp, MaterialTheme.colorScheme.primary, CircleShape
                                                        ) else Modifier
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    T.dayNumber(day),
                                                    color = if (selected) MaterialTheme.colorScheme.onPrimary
                                                    else MaterialTheme.colorScheme.onSurface,
                                                    fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal
                                                )
                                            }
                                            Row(
                                                Modifier.height(8.dp),
                                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                                            ) {
                                                repeat(minOf(count, 3)) {
                                                    Box(
                                                        Modifier
                                                            .padding(top = 2.dp)
                                                            .size(4.dp)
                                                            .clip(CircleShape)
                                                            .background(MaterialTheme.colorScheme.tertiary)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            SectionHeader(T.dayTitle(anchor))
            DayEvents(events, anchor, onEdit)
        }
        item {
            SectionHeader(stringResource(R.string.upcoming_events))
            if (upcoming.isEmpty()) {
                EmptyCardText(stringResource(R.string.no_events))
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    upcoming.forEach { e -> EventRow(e, onClick = { onEdit(e) }, showDate = true) }
                }
            }
        }
    }
}

@Composable
private fun WeekView(
    events: List<EventItem>, anchor: Long,
    onSelect: (Long) -> Unit, onEdit: (EventItem) -> Unit
) {
    val start = T.weekStart(anchor)
    val today = T.startOfDay(T.now())
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                for (d in 0 until 7) {
                    val day = T.addDays(start, d)
                    val selected = T.sameDay(day, anchor)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clip(MaterialTheme.shapes.small)
                            .clickable { onSelect(day) }
                            .padding(vertical = 6.dp)
                    ) {
                        Text(
                            T.weekdayShort(T.weekdayOf(day)),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(4.dp))
                        Box(
                            Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    if (selected) MaterialTheme.colorScheme.primary else Color.Transparent
                                )
                                .then(
                                    if (day == today && !selected) Modifier.border(
                                        1.5.dp, MaterialTheme.colorScheme.primary, CircleShape
                                    ) else Modifier
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                T.dayNumber(day),
                                color = if (selected) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
        items(7) { d ->
            val day = T.addDays(start, d)
            SectionHeader(T.dayTitle(day))
            DayEvents(events, day, onEdit)
        }
    }
}

@Composable
private fun DayView(events: List<EventItem>, anchor: Long, onEdit: (EventItem) -> Unit) {
    val dayEvents = events.filter { it.onDay(anchor) }
    val allDay = dayEvents.filter { it.allDay }
    val timed = dayEvents.filter { !it.allDay }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp)
    ) {
        if (allDay.isNotEmpty()) {
            item {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    allDay.forEach { e -> EventRow(e, onClick = { onEdit(e) }) }
                }
            }
        }
        if (dayEvents.isEmpty()) {
            item { EmptyCardText(stringResource(R.string.no_events_day)) }
        }
        items(24) { h ->
            val slotStart = T.withTime(anchor, h, 0)
            val slotEnd = slotStart + 3_600_000L
            val inSlot = timed.filter { it.startMillis in slotStart until slotEnd }
            Row(Modifier.heightIn(min = 56.dp)) {
                Text(
                    T.hourLabel(h),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .width(76.dp)
                        .padding(top = 6.dp)
                )
                Column(
                    Modifier
                        .weight(1f)
                        .padding(vertical = 3.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    inSlot.forEach { e -> EventRow(e, onClick = { onEdit(e) }) }
                }
            }
        }
    }
}

@Composable
private fun EventDialog(
    event: EventItem,
    onSave: (EventItem) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(event.title) }
    var desc by remember { mutableStateOf(event.description) }
    var allDay by remember { mutableStateOf(event.allDay) }
    var start by remember { mutableLongStateOf(event.startMillis) }
    // For all-day events [end] is the exclusive end, show the last day to the user.
    var end by remember {
        mutableLongStateOf(if (event.allDay) event.endMillis - 1 else event.endMillis)
    }
    var remind by remember { mutableIntStateOf(event.remindMinutes) }
    var color by remember { mutableIntStateOf(event.color) }

    val remindValues = listOf(-1, 0, 10, 30, 60, 1440)
    val remindLabels = listOf(
        stringResource(R.string.remind_none), stringResource(R.string.remind_at_time),
        stringResource(R.string.remind_10m), stringResource(R.string.remind_30m),
        stringResource(R.string.remind_1h), stringResource(R.string.remind_1d)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(stringResource(if (onDelete == null) R.string.add_event else R.string.edit_event))
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text(stringResource(R.string.title)) },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = desc, onValueChange = { desc = it },
                    label = { Text(stringResource(R.string.description)) },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(stringResource(R.string.all_day), Modifier.weight(1f))
                    Switch(checked = allDay, onCheckedChange = { allDay = it })
                }
                FieldLabel(stringResource(R.string.starts))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DateField(start, { newStart ->
                        val duration = end - start
                        start = newStart
                        end = newStart + maxOf(duration, 0L)
                    })
                    if (!allDay) TimeField(start, { newStart ->
                        val duration = end - start
                        start = newStart
                        end = newStart + maxOf(duration, 0L)
                    })
                }
                FieldLabel(stringResource(R.string.ends))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DateField(end, { end = it })
                    if (!allDay) TimeField(end, { end = it })
                }
                FieldLabel(stringResource(R.string.reminder))
                ChipRow(remindLabels, remindValues.indexOf(remind).coerceAtLeast(0), { remind = remindValues[it] })
                FieldLabel(stringResource(R.string.color))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    EventAccent.forEachIndexed { i, c ->
                        Box(
                            Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(
                                    if (i == color) 3.dp else 0.dp,
                                    MaterialTheme.colorScheme.onSurface, CircleShape
                                )
                                .clickable { color = i }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank(),
                onClick = {
                    val s = if (allDay) T.startOfDay(start) else start
                    val e = if (allDay) T.endOfDay(maxOf(end, start)) else maxOf(end, start + 60_000L)
                    onSave(
                        event.copy(
                            title = title.trim(), description = desc.trim(), allDay = allDay,
                            startMillis = s, endMillis = e, remindMinutes = remind, color = color
                        )
                    )
                }
            ) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
            }
        }
    )
}
