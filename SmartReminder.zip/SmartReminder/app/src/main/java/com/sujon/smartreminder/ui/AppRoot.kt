package com.sujon.smartreminder.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.StickyNote2
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.sujon.smartreminder.AppViewModel
import com.sujon.smartreminder.R

private data class Tab(val route: String, val label: Int, val icon: ImageVector)

private val TABS = listOf(
    Tab("home", R.string.nav_home, Icons.Rounded.Home),
    Tab("notes", R.string.nav_notes, Icons.Rounded.StickyNote2),
    Tab("calendar", R.string.nav_calendar, Icons.Rounded.CalendarMonth),
    Tab("reminders", R.string.nav_reminders, Icons.Rounded.Notifications),
    Tab("tasks", R.string.nav_tasks, Icons.Rounded.CheckCircle)
)

/** Switches between the bottom-bar screens without piling up the back stack. */
fun NavController.goTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: AppViewModel, pendingRoute: MutableState<String?>, onSecureChanged: () -> Unit) {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val isTab = TABS.any { it.route == route }

    // Ask for the notification permission once (Android 13+).
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Short messages from the ViewModel (backup done, etc.)
    LaunchedEffect(Unit) {
        for (m in vm.messages) Toast.makeText(ctx, ctx.getString(m), Toast.LENGTH_LONG).show()
    }

    // Open a screen requested by a tapped notification.
    LaunchedEffect(pendingRoute.value) {
        val r = pendingRoute.value
        if (r != null) {
            if (TABS.any { it.route == r }) nav.goTab(r) else nav.navigate(r)
            pendingRoute.value = null
        }
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                if (isTab) {
                    TopAppBar(
                        title = {
                            Text(
                                stringResource(
                                    if (route == "home") R.string.app_name
                                    else TABS.first { it.route == route }.label
                                ),
                                fontWeight = FontWeight.Bold
                            )
                        },
                        actions = {
                            IconButton(onClick = { nav.navigate("search") }) {
                                Icon(Icons.Rounded.Search, stringResource(R.string.search))
                            }
                            IconButton(onClick = { nav.navigate("alarms") }) {
                                Icon(Icons.Rounded.Alarm, stringResource(R.string.alarms))
                            }
                            IconButton(onClick = { nav.navigate("settings") }) {
                                Icon(Icons.Rounded.Settings, stringResource(R.string.settings))
                            }
                        }
                    )
                }
            },
            bottomBar = {
                if (isTab) {
                    NavigationBar {
                        TABS.forEach { tab ->
                            NavigationBarItem(
                                selected = route == tab.route,
                                onClick = { nav.goTab(tab.route) },
                                icon = { Icon(tab.icon, null) },
                                label = { Text(stringResource(tab.label), maxLines = 1) }
                            )
                        }
                    }
                }
            }
        ) { inner ->
            NavHost(
                navController = nav,
                startDestination = "home",
                modifier = Modifier.padding(inner),
                enterTransition = { fadeIn(tween(250)) + slideInHorizontally(tween(300)) { it / 12 } },
                exitTransition = { fadeOut(tween(150)) },
                popEnterTransition = { fadeIn(tween(250)) },
                popExitTransition = { fadeOut(tween(150)) + slideOutHorizontally(tween(250)) { it / 12 } }
            ) {
                composable("home") { HomeScreen(vm, nav) }
                composable("notes") { NotesScreen(vm, nav) }
                composable("calendar") { CalendarScreen(vm, nav) }
                composable("reminders") { RemindersScreen(vm, nav) }
                composable("tasks") { TasksScreen(vm, nav) }
                composable("alarms") { AlarmsScreen(vm, nav) }
                composable("search") { SearchScreen(vm, nav) }
                composable("settings") { SettingsScreen(vm, nav, onSecureChanged) }
                composable("about") { AboutScreen(nav) }
                composable(
                    "note/{id}",
                    arguments = listOf(navArgument("id") { type = NavType.LongType })
                ) { e ->
                    NoteEditor(vm, nav, e.arguments?.getLong("id") ?: 0L)
                }
            }
        }

        // PIN lock sits on top of everything.
        if (vm.locked) LockScreen(vm)
    }
}
