package com.sujon.smartreminder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckBox
import androidx.compose.material.icons.rounded.CheckBoxOutlineBlank
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sujon.smartreminder.R
import com.sujon.smartreminder.data.EventItem
import com.sujon.smartreminder.data.Note
import com.sujon.smartreminder.data.Reminder
import com.sujon.smartreminder.data.TaskItem
import com.sujon.smartreminder.data.parseChecklist
import com.sujon.smartreminder.util.T

@Composable
fun repeatLabels(): List<String> = listOf(
    stringResource(R.string.repeat_none), stringResource(R.string.repeat_daily),
    stringResource(R.string.repeat_weekly), stringResource(R.string.repeat_monthly)
)

@Composable
fun priorityLabels(): List<String> = listOf(
    stringResource(R.string.priority_low), stringResource(R.string.priority_medium),
    stringResource(R.string.priority_high)
)

@Composable
fun NoteCard(note: Note, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = noteColor(note.color)),
        shape = MaterialTheme.shapes.medium
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                if (note.title.isNotBlank()) {
                    Text(
                        note.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    Spacer(Modifier.weight(1f))
                }
                if (note.pinned) {
                    Icon(
                        Icons.Rounded.PushPin, null, Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
            if (note.isChecklist) {
                val items = parseChecklist(note.checklist)
                items.take(6).forEach { item ->
                    Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (item.checked) Icons.Rounded.CheckBox else Icons.Rounded.CheckBoxOutlineBlank,
                            null, Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            item.text,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textDecoration = if (item.checked) TextDecoration.LineThrough else null
                        )
                    }
                }
                if (items.size > 6) {
                    Text(
                        "+${items.size - 6}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            } else if (note.body.isNotBlank()) {
                Text(
                    note.body,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 7,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
            if (note.audioPath.isNotEmpty()) {
                Icon(
                    Icons.Rounded.Mic, null,
                    Modifier
                        .padding(top = 8.dp)
                        .size(18.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun TaskRow(task: TaskItem, onToggle: () -> Unit, onClick: () -> Unit) {
    val overdue = !task.done && task.deadline > 0 && task.deadline < T.now()
    val prio = PriorityColors[task.priority.coerceIn(0, 2)]
    ClickableCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(end = 14.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = task.done, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f)) {
                Text(
                    task.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    textDecoration = if (task.done) TextDecoration.LineThrough else null,
                    color = if (task.done) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.onSurface
                )
                if (task.deadline > 0) {
                    Text(
                        T.full(task.deadline),
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (overdue) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Box(
                Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(prio)
            )
        }
    }
}

@Composable
fun ReminderRow(
    r: Reminder,
    onToggle: () -> Unit,
    onClick: () -> Unit,
    trailing: @Composable () -> Unit = {}
) {
    val overdue = !r.completed && r.timeMillis < T.now()
    ClickableCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(end = 6.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = r.completed, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f)) {
                Text(
                    r.title.ifBlank { stringResource(R.string.reminder) },
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    textDecoration = if (r.completed) TextDecoration.LineThrough else null,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        T.full(r.timeMillis),
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (overdue) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (r.repeat != 0) {
                        Spacer(Modifier.width(6.dp))
                        Icon(
                            Icons.Rounded.Repeat, null, Modifier.size(14.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (r.isMessage) {
                        Spacer(Modifier.width(6.dp))
                        Icon(
                            Icons.Rounded.Sms, null, Modifier.size(14.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
            trailing()
        }
    }
}

@Composable
fun EventRow(e: EventItem, onClick: () -> Unit, showDate: Boolean = false) {
    val accent = EventAccent[e.color.coerceIn(0, EventAccent.size - 1)]
    ClickableCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .width(6.dp)
                    .background(accent, RoundedCornerShape(topStart = 18.dp, bottomStart = 18.dp))
            )
            Column(Modifier.padding(12.dp)) {
                Text(
                    e.title.ifBlank { stringResource(R.string.event) },
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium
                )
                val whenText = when {
                    e.allDay -> if (showDate) T.date(e.startMillis) + " · " + stringResource(R.string.all_day)
                    else stringResource(R.string.all_day)
                    showDate -> T.date(e.startMillis) + " · " + T.time(e.startMillis)
                    else -> T.time(e.startMillis) + " – " + T.time(e.endMillis)
                }
                Text(
                    whenText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
