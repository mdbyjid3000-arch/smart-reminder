package com.sujon.smartreminder

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.mutableStateOf
import com.sujon.smartreminder.ui.AppRoot
import com.sujon.smartreminder.ui.SmartReminderTheme
import com.sujon.smartreminder.util.AppFlags

class MainActivity : AppCompatActivity() {

    private val vm: AppViewModel by viewModels()
    private val pendingRoute = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        pendingRoute.value = intent?.getStringExtra("route")
        applySecure()
        setContent {
            SmartReminderTheme {
                AppRoot(vm = vm, pendingRoute = pendingRoute, onSecureChanged = { applySecure() })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingRoute.value = intent.getStringExtra("route")
    }

    override fun onStart() {
        super.onStart()
        AppFlags.skipLock = false
    }

    override fun onStop() {
        super.onStop()
        // Lock again when the app goes to the background (unless a system picker is open).
        if (!AppFlags.skipLock && !isChangingConfigurations) vm.lockNow()
    }

    private fun applySecure() {
        if (vm.secure) {
            window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
}
