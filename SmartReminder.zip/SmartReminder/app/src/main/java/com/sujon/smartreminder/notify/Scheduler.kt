package com.sujon.smartreminder.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import com.sujon.smartreminder.MainActivity
import com.sujon.smartreminder.data.AppDb
import com.sujon.smartreminder.data.triggerAt
import com.sujon.smartreminder.util.T

object Scheduler {
    const val T_REMINDER = 1
    const val T_ALARM = 2
    const val T_EVENT = 3

    private fun pending(ctx: Context, type: Int, id: Long, snooze: Boolean): PendingIntent {
        val intent = Intent(ctx, AlarmReceiver::class.java)
            .setData(Uri.parse("smartreminder://fire/$type/$id/$snooze"))
            .putExtra("type", type)
            .putExtra("id", id)
            .putExtra("snooze", snooze)
        return PendingIntent.getBroadcast(
            ctx, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun showIntent(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun canScheduleExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }

    /** Schedules one wake-up. Uses an exact alarm when allowed, otherwise the closest inexact one. */
    fun scheduleAt(ctx: Context, type: Int, id: Long, at: Long, snooze: Boolean = false) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx, type, id, snooze)
        try {
            if (canScheduleExact(ctx)) {
                if (type == T_ALARM && !snooze) {
                    am.setAlarmClock(AlarmManager.AlarmClockInfo(at, showIntent(ctx)), pi)
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                }
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(ctx: Context, type: Int, id: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx, type, id, false))
        am.cancel(pending(ctx, type, id, true))
    }

    /** Re-creates every scheduled wake-up from the database (boot, update, restore, app start). */
    suspend fun rescheduleAll(ctx: Context) {
        val db = AppDb.get(ctx)
        val now = T.now()

        db.reminders().all().filter { !it.completed }.forEach { r ->
            var t = r.timeMillis
            if (r.repeat != 0 && t <= now) {
                t = T.nextRepeat(t, r.repeat, now)
                db.reminders().upsert(r.copy(timeMillis = t))
            }
            if (t > now) scheduleAt(ctx, T_REMINDER, r.id, t)
        }
        db.alarms().all().forEach { a ->
            if (a.enabled) {
                scheduleAt(ctx, T_ALARM, a.id, T.nextAlarm(a.hour, a.minute, a.days))
            } else {
                cancel(ctx, T_ALARM, a.id)
            }
        }
        db.events().all().forEach { e ->
            if (e.remindMinutes >= 0) {
                val at = e.triggerAt()
                if (at > now) scheduleAt(ctx, T_EVENT, e.id, at)
            }
        }
    }

    /** Cancels every scheduled wake-up that currently exists (used before a restore). */
    suspend fun cancelAll(ctx: Context) {
        val db = AppDb.get(ctx)
        db.reminders().all().forEach { cancel(ctx, T_REMINDER, it.id) }
        db.alarms().all().forEach { cancel(ctx, T_ALARM, it.id) }
        db.events().all().forEach { cancel(ctx, T_EVENT, it.id) }
    }
}
