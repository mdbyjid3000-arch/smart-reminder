package com.sujon.smartreminder.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.StickyNote2
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.sujon.smartreminder.AppViewModel
import com.sujon.smartreminder.R
import com.sujon.smartreminder.util.T

@Composable
fun ProgressRing(progress: Float, label: String, modifier: Modifier = Modifier.size(104.dp)) {
    var target by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(progress) { target = progress }
    val anim by animateFloatAsState(target, tween(900), label = "ring")
    val track = MaterialTheme.colorScheme.surfaceVariant
    val color = MaterialTheme.colorScheme.primary
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 12.dp.toPx()
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val topLeft = Offset(stroke / 2, stroke / 2)
            drawArc(track, 0f, 360f, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(color, -90f, 360f * anim, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Text(label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun HomeScreen(vm: AppViewModel, nav: NavController) {
    val notes by vm.notes.collectAsStateWithLifecycle()
    val reminders by vm.reminders.collectAsStateWithLifecycle()
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val events by vm.events.collectAsStateWithLifecycle()

    val now = T.now()
    val today = T.startOfDay(now)
    val tomorrow = T.addDays(today, 1)

    val pendingReminders = reminders.filter { !it.completed }.sortedBy { it.timeMillis }
    val upcoming = pendingReminders.take(3)
    val todayTasks = tasks.filter { !it.done && it.deadline in 1L until tomorrow }
    val tasksDone = tasks.count { it.done }
    val remindersDone = reminders.count { it.completed }
    val total = tasks.size + reminders.size
    val progress = if (total == 0) 0f else (tasksDone + remindersDone).toFloat() / total
    val weekStart = T.weekStart(now)
    val weekEnd = T.addDays(weekStart, 7)
    val weekEvents = events.count { it.startMillis in weekStart until weekEnd }
    val upcomingEvents = events.filter { it.startMillis >= now }.take(3)
    val recentNotes = notes.filter { !it.archived }.take(6)

    val hour = T.hour(now)
    val greeting = when {
        hour < 12 -> R.string.greet_morning
        hour < 17 -> R.string.greet_afternoon
        else -> R.string.greet_evening
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp
        )
    ) {
        item {
            Appear(0) {
                Column {
                    PermissionBanners()
                    Spacer(Modifier.height(8.dp))
                    // Hero card with today's date
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(28.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.primary,
                                        MaterialTheme.colorScheme.tertiary
                                    )
                                )
                            )
                            .padding(22.dp)
                    ) {
                        Column {
                            Text(
                                stringResource(greeting),
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                T.dayTitle(now),
                                style = MaterialTheme.typography.headlineMedium,
                                color = Color.White
                            )
                            Spacer(Modifier.height(10.dp))
                            Text(
                                stringResource(R.string.home_summary, todayTasks.size, pendingReminders.size),
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }
                    }
                }
            }
        }

        item {
            Appear(1) {
                Column {
                    SectionHeader(stringResource(R.string.completion_stats))
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                            ProgressRing(progress, "${(progress * 100).toInt()}%")
                            Spacer(Modifier.width(20.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                StatLine(Icons.Rounded.CheckCircle, stringResource(R.string.tasks), "$tasksDone/${tasks.size}")
                                StatLine(Icons.Rounded.Notifications, stringResource(R.string.reminders), "$remindersDone/${reminders.size}")
                                StatLine(Icons.Rounded.Event, stringResource(R.string.events_this_week), "$weekEvents")
                                StatLine(Icons.Rounded.StickyNote2, stringResource(R.string.notes), "${notes.count { !it.archived }}")
                            }
                        }
                    }
                }
            }
        }

        item {
            Appear(2) {
                Column {
                    SectionHeader(stringResource(R.string.upcoming_reminders), stringResource(R.string.see_all)) {
                        nav.goTab("reminders")
                    }
                    if (upcoming.isEmpty()) {
                        EmptyCardText(stringResource(R.string.no_reminders))
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            upcoming.forEach { r ->
                                ReminderRow(r, onToggle = { vm.toggleReminder(r) }, onClick = { nav.goTab("reminders") })
                            }
                        }
                    }
                }
            }
        }

        item {
            Appear(3) {
                Column {
                    SectionHeader(stringResource(R.string.todays_tasks), stringResource(R.string.see_all)) {
                        nav.goTab("tasks")
                    }
                    if (todayTasks.isEmpty()) {
                        EmptyCardText(stringResource(R.string.no_tasks_today))
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            todayTasks.take(4).forEach { t ->
                                TaskRow(t, onToggle = { vm.toggleTask(t) }, onClick = { nav.goTab("tasks") })
                            }
                        }
                    }
                }
            }
        }

        item {
            Appear(4) {
                Column {
                    SectionHeader(stringResource(R.string.calendar_overview), stringResource(R.string.open)) {
                        nav.goTab("calendar")
                    }
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { nav.goTab("calendar") }
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                for (d in 0 until 7) {
                                    val day = T.addDays(weekStart, d)
                                    val isToday = T.sameDay(day, now)
                                    val hasEvent = events.any { it.startMillis in day until T.endOfDay(day) }
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(
                                            T.weekdayShort(T.weekdayOf(day)),
                                            style = MaterialTheme.typography.labelLarge,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(Modifier.height(4.dp))
                                        Box(
                                            Modifier
                                                .size(34.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (isToday) MaterialTheme.colorScheme.primary
                                                    else Color.Transparent
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                T.dayNumber(day),
                                                color = if (isToday) MaterialTheme.colorScheme.onPrimary
                                                else MaterialTheme.colorScheme.onSurface,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                        Spacer(Modifier.height(4.dp))
                                        Box(
                                            Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (hasEvent) MaterialTheme.colorScheme.tertiary
                                                    else Color.Transparent
                                                )
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    if (upcomingEvents.isEmpty()) {
                        EmptyCardText(stringResource(R.string.no_events))
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            upcomingEvents.forEach { e -> EventRow(e, onClick = { nav.goTab("calendar") }, showDate = true) }
                        }
                    }
                }
            }
        }

        item {
            Appear(5) {
                Column {
                    SectionHeader(stringResource(R.string.quick_notes), stringResource(R.string.see_all)) {
                        nav.goTab("notes")
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        item {
                            Card(
                                modifier = Modifier
                                    .width(120.dp)
                                    .height(110.dp)
                                    .clickable { nav.navigate("note/0") },
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer
                                )
                            ) {
                                Column(
                                    Modifier.fillMaxSize(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(Icons.Rounded.Add, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                    Text(
                                        stringResource(R.string.new_note),
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                }
                            }
                        }
                        items(recentNotes, key = { it.id }) { n ->
                            NoteCard(n, onClick = { nav.navigate("note/${n.id}") }, modifier = Modifier.width(170.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatLine(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(8.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.width(110.dp))
        Text(value, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun EmptyCardText(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp)
    )
}
