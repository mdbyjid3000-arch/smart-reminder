package com.sujon.smartreminder.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary = Color(0xFF5B4BDB),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE5E0FF),
    onPrimaryContainer = Color(0xFF1B0F6B),
    secondary = Color(0xFF00897B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFCCF2EC),
    onSecondaryContainer = Color(0xFF00201C),
    tertiary = Color(0xFFE8576F),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFD9DE),
    onTertiaryContainer = Color(0xFF3F0014),
    background = Color(0xFFFBF9FF),
    onBackground = Color(0xFF1C1B21),
    surface = Color(0xFFFBF9FF),
    onSurface = Color(0xFF1C1B21),
    surfaceVariant = Color(0xFFE8E3F1),
    onSurfaceVariant = Color(0xFF49454F),
    outline = Color(0xFF7A757F),
    outlineVariant = Color(0xFFCAC4D0),
    error = Color(0xFFBA1A1A),
    errorContainer = Color(0xFFFFDAD6)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFC6BFFF),
    onPrimary = Color(0xFF2D1F9E),
    primaryContainer = Color(0xFF4433C0),
    onPrimaryContainer = Color(0xFFE5E0FF),
    secondary = Color(0xFF7DD8CB),
    onSecondary = Color(0xFF003731),
    secondaryContainer = Color(0xFF00504A),
    onSecondaryContainer = Color(0xFFCCF2EC),
    tertiary = Color(0xFFFFB2BE),
    onTertiary = Color(0xFF66002A),
    tertiaryContainer = Color(0xFF8D1E40),
    onTertiaryContainer = Color(0xFFFFD9DE),
    background = Color(0xFF131218),
    onBackground = Color(0xFFE5E1E9),
    surface = Color(0xFF131218),
    onSurface = Color(0xFFE5E1E9),
    surfaceVariant = Color(0xFF2B2833),
    onSurfaceVariant = Color(0xFFCAC4D0),
    outline = Color(0xFF948F99),
    outlineVariant = Color(0xFF49454F),
    error = Color(0xFFFFB4AB),
    errorContainer = Color(0xFF93000A)
)

private val AppTypography = Typography(
    headlineMedium = TextStyle(fontSize = 28.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(26.dp)
)

@Composable
fun SmartReminderTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}

private val NoteLight = listOf(
    Color(0xFFF1EEF9), Color(0xFFFFE0E0), Color(0xFFFFE9C7), Color(0xFFFFF7BF),
    Color(0xFFDDF5D0), Color(0xFFCFF3EE), Color(0xFFD6E7FF), Color(0xFFEBD9FF)
)
private val NoteDark = listOf(
    Color(0xFF2B2833), Color(0xFF5A2A2A), Color(0xFF5A4020), Color(0xFF55511F),
    Color(0xFF2F4A29), Color(0xFF1F4A45), Color(0xFF263F63), Color(0xFF44305F)
)

const val NOTE_COLOR_COUNT = 8

@Composable
fun noteColor(index: Int): Color {
    val list = if (isSystemInDarkTheme()) NoteDark else NoteLight
    return list[index.coerceIn(0, NOTE_COLOR_COUNT - 1)]
}

/** Accent colours used for calendar events (0..5). */
val EventAccent = listOf(
    Color(0xFF5B4BDB), Color(0xFF00897B), Color(0xFFE8576F),
    Color(0xFFF59E0B), Color(0xFF2F80ED), Color(0xFF8E44AD)
)

val PriorityColors = listOf(Color(0xFF2E9E6B), Color(0xFFF59E0B), Color(0xFFE5484D))
