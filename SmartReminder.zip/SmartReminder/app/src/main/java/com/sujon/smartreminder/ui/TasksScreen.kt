package com.sujon.smartreminder.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.sujon.smartreminder.AppViewModel
import com.sujon.smartreminder.R
import com.sujon.smartreminder.data.TaskItem
import com.sujon.smartreminder.util.T

@Composable
fun TasksScreen(vm: AppViewModel, nav: NavController) {
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    var filter by remember { mutableIntStateOf(0) } // 0 all, 1 pending, 2 done
    var dialog by remember { mutableStateOf<TaskItem?>(null) }

    val done = tasks.count { it.done }
    val progress = if (tasks.isEmpty()) 0f else done.toFloat() / tasks.size
    val animated by animateFloatAsState(progress, label = "task-progress")

    val shown = tasks.filter {
        when (filter) {
            1 -> !it.done
            2 -> it.done
            else -> true
        }
    }.sortedWith(
        compareBy<TaskItem> { it.done }
            .thenByDescending { it.priority }
            .thenBy { if (it.deadline == 0L) Long.MAX_VALUE else it.deadline }
    )

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(
                    stringResource(R.string.tasks_progress, done, tasks.size),
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { animated },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp),
                    strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
                )
                Spacer(Modifier.height(12.dp))
                ChipRow(
                    listOf(
                        stringResource(R.string.all), stringResource(R.string.pending),
                        stringResource(R.string.completed)
                    ),
                    filter, { filter = it }
                )
            }
            if (shown.isEmpty()) {
                EmptyState(Icons.Rounded.CheckCircle, stringResource(R.string.no_tasks))
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(shown, key = { it.id }) { t ->
                        TaskRow(t, onToggle = { vm.toggleTask(t) }, onClick = { dialog = t })
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { dialog = TaskItem() },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) { Icon(Icons.Rounded.Add, stringResource(R.string.add_task)) }
    }

    dialog?.let { t ->
        TaskDialog(
            task = t,
            onSave = {
                vm.saveTask(it)
                dialog = null
            },
            onDelete = if (t.id != 0L) {
                {
                    vm.deleteTask(t)
                    dialog = null
                }
            } else null,
            onDismiss = { dialog = null }
        )
    }
}

@Composable
private fun TaskDialog(
    task: TaskItem,
    onSave: (TaskItem) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(task.title) }
    var priority by remember { mutableIntStateOf(task.priority) }
    var hasDeadline by remember { mutableStateOf(task.deadline > 0) }
    var deadline by remember {
        mutableLongStateOf(
            if (task.deadline > 0) task.deadline else {
                val today18 = T.withTime(T.now(), 18, 0)
                if (today18 > T.now()) today18 else T.withTime(T.addDays(T.now(), 1), 9, 0)
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(if (onDelete == null) R.string.add_task else R.string.edit_task)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text(stringResource(R.string.title)) },
                    modifier = Modifier.fillMaxWidth()
                )
                FieldLabel(stringResource(R.string.priority))
                ChipRow(priorityLabels(), priority, { priority = it })
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(stringResource(R.string.deadline), Modifier.weight(1f))
                    Switch(checked = hasDeadline, onCheckedChange = { hasDeadline = it })
                }
                if (hasDeadline) {
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DateField(deadline, { deadline = it })
                        TimeField(deadline, { deadline = it })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank(),
                onClick = {
                    onSave(
                        task.copy(
                            title = title.trim(), priority = priority,
                            deadline = if (hasDeadline) deadline else 0L
                        )
                    )
                }
            ) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
            }
        }
    )
}
