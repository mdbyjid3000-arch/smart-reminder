package com.sujon.smartreminder.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.StickyNote2
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.sujon.smartreminder.AppViewModel
import com.sujon.smartreminder.R
import com.sujon.smartreminder.util.T

/** Searches notes, reminders, tasks, events and alarms at once. */
@Composable
fun SearchScreen(vm: AppViewModel, nav: NavController) {
    val notes by vm.notes.collectAsStateWithLifecycle()
    val reminders by vm.reminders.collectAsStateWithLifecycle()
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val events by vm.events.collectAsStateWithLifecycle()
    val alarms by vm.alarms.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    val q = query.trim()
    val fNotes = if (q.isEmpty()) emptyList() else notes.filter { it.matches(q) }
    val fReminders = if (q.isEmpty()) emptyList() else reminders.filter {
        it.title.contains(q, true) || it.notes.contains(q, true) || it.message.contains(q, true) ||
            it.phone.contains(q, true)
    }
    val fTasks = if (q.isEmpty()) emptyList() else tasks.filter { it.title.contains(q, true) }
    val fEvents = if (q.isEmpty()) emptyList() else events.filter {
        it.title.contains(q, true) || it.description.contains(q, true)
    }
    val fAlarms = if (q.isEmpty()) emptyList() else alarms.filter { it.label.contains(q, true) }
    val nothing = q.isNotEmpty() && fNotes.isEmpty() && fReminders.isEmpty() &&
        fTasks.isEmpty() && fEvents.isEmpty() && fAlarms.isEmpty()

    Scaffold(topBar = { SubTopBar(stringResource(R.string.search), onBack = { nav.popBackStack() }) }) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text(stringResource(R.string.search_everything)) },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Clear, null) }
                    }
                },
                shape = androidx.compose.material3.MaterialTheme.shapes.large,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .focusRequester(focus)
            )
            if (q.isEmpty()) {
                EmptyState(Icons.Rounded.Search, stringResource(R.string.search_hint))
            } else if (nothing) {
                EmptyState(Icons.Rounded.Search, stringResource(R.string.no_results))
            } else {
                LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)) {
                    if (fNotes.isNotEmpty()) {
                        item { SectionHeader(stringResource(R.string.notes)) }
                        fNotes.forEach { n ->
                            item(key = "n${n.id}") {
                                ListItem(
                                    leadingContent = { Icon(Icons.Rounded.StickyNote2, null) },
                                    headlineContent = {
                                        Text(n.title.ifBlank { n.body.lines().firstOrNull() ?: "" }, maxLines = 1)
                                    },
                                    modifier = Modifier.clickable { nav.navigate("note/${n.id}") }
                                )
                            }
                        }
                    }
                    if (fReminders.isNotEmpty()) {
                        item { SectionHeader(stringResource(R.string.reminders)) }
                        fReminders.forEach { r ->
                            item(key = "r${r.id}") {
                                ListItem(
                                    leadingContent = { Icon(Icons.Rounded.Notifications, null) },
                                    headlineContent = { Text(r.title.ifBlank { r.message }, maxLines = 1) },
                                    supportingContent = { Text(T.full(r.timeMillis)) },
                                    modifier = Modifier.clickable { nav.goTab("reminders") }
                                )
                            }
                        }
                    }
                    if (fTasks.isNotEmpty()) {
                        item { SectionHeader(stringResource(R.string.tasks)) }
                        fTasks.forEach { t ->
                            item(key = "t${t.id}") {
                                ListItem(
                                    leadingContent = { Icon(Icons.Rounded.CheckCircle, null) },
                                    headlineContent = { Text(t.title, maxLines = 1) },
                                    modifier = Modifier.clickable { nav.goTab("tasks") }
                                )
                            }
                        }
                    }
                    if (fEvents.isNotEmpty()) {
                        item { SectionHeader(stringResource(R.string.events)) }
                        fEvents.forEach { e ->
                            item(key = "e${e.id}") {
                                ListItem(
                                    leadingContent = { Icon(Icons.Rounded.Event, null) },
                                    headlineContent = { Text(e.title, maxLines = 1) },
                                    supportingContent = { Text(T.full(e.startMillis)) },
                                    modifier = Modifier.clickable { nav.goTab("calendar") }
                                )
                            }
                        }
                    }
                    if (fAlarms.isNotEmpty()) {
                        item { SectionHeader(stringResource(R.string.alarms)) }
                        fAlarms.forEach { a ->
                            item(key = "a${a.id}") {
                                ListItem(
                                    leadingContent = { Icon(Icons.Rounded.Alarm, null) },
                                    headlineContent = { Text(a.label, maxLines = 1) },
                                    supportingContent = { Text(T.hm(a.hour, a.minute)) },
                                    modifier = Modifier.clickable { nav.navigate("alarms") }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
