package com.sujon.smartreminder.data

import androidx.room.withTransaction
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/** Exports / imports all app data as one JSON file. Voice recordings are not included. */
object Backup {

    suspend fun write(db: AppDb, out: OutputStream) {
        val root = JSONObject()
        root.put("app", "SmartReminder")
        root.put("version", 1)

        val notes = JSONArray()
        db.notes().all().forEach {
            notes.put(
                JSONObject().put("id", it.id).put("title", it.title).put("body", it.body)
                    .put("color", it.color).put("pinned", it.pinned).put("archived", it.archived)
                    .put("isChecklist", it.isChecklist).put("checklist", it.checklist)
                    .put("audioPath", it.audioPath).put("updatedAt", it.updatedAt)
            )
        }
        root.put("notes", notes)

        val reminders = JSONArray()
        db.reminders().all().forEach {
            reminders.put(
                JSONObject().put("id", it.id).put("title", it.title).put("notes", it.notes)
                    .put("timeMillis", it.timeMillis).put("repeat", it.repeat)
                    .put("sound", it.sound).put("completed", it.completed)
                    .put("isMessage", it.isMessage).put("phone", it.phone)
                    .put("message", it.message)
            )
        }
        root.put("reminders", reminders)

        val alarms = JSONArray()
        db.alarms().all().forEach {
            alarms.put(
                JSONObject().put("id", it.id).put("hour", it.hour).put("minute", it.minute)
                    .put("label", it.label).put("days", it.days).put("enabled", it.enabled)
                    .put("sound", it.sound)
            )
        }
        root.put("alarms", alarms)

        val tasks = JSONArray()
        db.tasks().all().forEach {
            tasks.put(
                JSONObject().put("id", it.id).put("title", it.title).put("priority", it.priority)
                    .put("deadline", it.deadline).put("done", it.done)
                    .put("createdAt", it.createdAt).put("doneAt", it.doneAt)
            )
        }
        root.put("tasks", tasks)

        val events = JSONArray()
        db.events().all().forEach {
            events.put(
                JSONObject().put("id", it.id).put("title", it.title)
                    .put("description", it.description).put("startMillis", it.startMillis)
                    .put("endMillis", it.endMillis).put("allDay", it.allDay)
                    .put("remindMinutes", it.remindMinutes).put("color", it.color)
            )
        }
        root.put("events", events)

        out.write(root.toString(2).toByteArray(Charsets.UTF_8))
        out.flush()
    }

    /** Replaces all existing data. Throws if the file is not a valid backup. */
    suspend fun read(db: AppDb, input: InputStream) {
        val root = JSONObject(input.readBytes().toString(Charsets.UTF_8))
        require(root.optString("app") == "SmartReminder") { "Not a Smart Reminder backup" }

        val notes = root.optJSONArray("notes").toList { o ->
            val audio = o.optString("audioPath")
            Note(
                id = o.getLong("id"), title = o.optString("title"), body = o.optString("body"),
                color = o.optInt("color"), pinned = o.optBoolean("pinned"),
                archived = o.optBoolean("archived"), isChecklist = o.optBoolean("isChecklist"),
                checklist = o.optString("checklist"),
                audioPath = if (audio.isNotEmpty() && File(audio).exists()) audio else "",
                updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
            )
        }
        val reminders = root.optJSONArray("reminders").toList { o ->
            Reminder(
                id = o.getLong("id"), title = o.optString("title"), notes = o.optString("notes"),
                timeMillis = o.optLong("timeMillis"), repeat = o.optInt("repeat"),
                sound = o.optString("sound", "default"), completed = o.optBoolean("completed"),
                isMessage = o.optBoolean("isMessage"), phone = o.optString("phone"),
                message = o.optString("message")
            )
        }
        val alarms = root.optJSONArray("alarms").toList { o ->
            AlarmItem(
                id = o.getLong("id"), hour = o.optInt("hour"), minute = o.optInt("minute"),
                label = o.optString("label"), days = o.optInt("days"),
                enabled = o.optBoolean("enabled"), sound = o.optString("sound", "default")
            )
        }
        val tasks = root.optJSONArray("tasks").toList { o ->
            TaskItem(
                id = o.getLong("id"), title = o.optString("title"), priority = o.optInt("priority"),
                deadline = o.optLong("deadline"), done = o.optBoolean("done"),
                createdAt = o.optLong("createdAt"), doneAt = o.optLong("doneAt")
            )
        }
        val events = root.optJSONArray("events").toList { o ->
            EventItem(
                id = o.getLong("id"), title = o.optString("title"),
                description = o.optString("description"), startMillis = o.optLong("startMillis"),
                endMillis = o.optLong("endMillis"), allDay = o.optBoolean("allDay"),
                remindMinutes = o.optInt("remindMinutes", -1), color = o.optInt("color")
            )
        }

        db.withTransaction {
            db.notes().clear(); notes.forEach { db.notes().upsert(it) }
            db.reminders().clear(); reminders.forEach { db.reminders().upsert(it) }
            db.alarms().clear(); alarms.forEach { db.alarms().upsert(it) }
            db.tasks().clear(); tasks.forEach { db.tasks().upsert(it) }
            db.events().clear(); events.forEach { db.events().upsert(it) }
        }
    }

    private fun <T> JSONArray?.toList(map: (JSONObject) -> T): List<T> {
        if (this == null) return emptyList()
        val list = ArrayList<T>(length())
        for (i in 0 until length()) list.add(map(getJSONObject(i)))
        return list
    }
}
