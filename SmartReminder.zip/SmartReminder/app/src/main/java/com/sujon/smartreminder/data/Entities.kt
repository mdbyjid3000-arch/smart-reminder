package com.sujon.smartreminder.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val body: String = "",
    val color: Int = 0,
    val pinned: Boolean = false,
    val archived: Boolean = false,
    val isChecklist: Boolean = false,
    val checklist: String = "",
    val audioPath: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

data class CheckItem(val checked: Boolean, val text: String)

fun parseChecklist(s: String): List<CheckItem> =
    s.lines().filter { it.isNotEmpty() }
        .map { CheckItem(it.startsWith("1|"), it.substringAfter('|')) }

fun encodeChecklist(items: List<CheckItem>): String =
    items.joinToString("\n") { (if (it.checked) "1|" else "0|") + it.text.replace("\n", " ") }

/** repeat: 0 = none, 1 = daily, 2 = weekly, 3 = monthly */
@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val notes: String = "",
    val timeMillis: Long = 0,
    val repeat: Int = 0,
    val sound: String = "default",
    val completed: Boolean = false,
    val isMessage: Boolean = false,
    val phone: String = "",
    val message: String = ""
)

/** days: bit mask, bit 0 = Sunday ... bit 6 = Saturday. 0 = ring once. */
@Entity(tableName = "alarms")
data class AlarmItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val hour: Int = 7,
    val minute: Int = 0,
    val label: String = "",
    val days: Int = 0,
    val enabled: Boolean = true,
    val sound: String = "default"
)

/** priority: 0 = low, 1 = medium, 2 = high. deadline 0 = none. */
@Entity(tableName = "tasks")
data class TaskItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val priority: Int = 1,
    val deadline: Long = 0,
    val done: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val doneAt: Long = 0
)

/** remindMinutes: -1 = no reminder, otherwise minutes before the start. */
@Entity(tableName = "events")
data class EventItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val description: String = "",
    val startMillis: Long = 0,
    val endMillis: Long = 0,
    val allDay: Boolean = false,
    val remindMinutes: Int = 10,
    val color: Int = 0
)

/** When the reminder of an event should fire. All-day events use 09:00 of that day as their start. */
fun EventItem.triggerAt(): Long =
    (if (allDay) startMillis + 9 * 3_600_000L else startMillis) - remindMinutes * 60_000L
