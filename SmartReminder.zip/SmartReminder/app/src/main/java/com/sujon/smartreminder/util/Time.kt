package com.sujon.smartreminder.util

import java.text.DateFormat
import java.text.DateFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object T {
    const val MIN = 60_000L

    fun now() = System.currentTimeMillis()

    fun cal(ms: Long = now()): Calendar = Calendar.getInstance().apply { timeInMillis = ms }

    fun startOfDay(ms: Long): Long = cal(ms).apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun addDays(ms: Long, n: Int): Long = cal(ms).apply { add(Calendar.DAY_OF_MONTH, n) }.timeInMillis

    fun addMonths(ms: Long, n: Int): Long = cal(ms).apply { add(Calendar.MONTH, n) }.timeInMillis

    /** Exclusive end of the day that contains [ms]. */
    fun endOfDay(ms: Long): Long = addDays(startOfDay(ms), 1)

    fun sameDay(a: Long, b: Long) = startOfDay(a) == startOfDay(b)

    fun withTime(dayMs: Long, h: Int, m: Int): Long = cal(dayMs).apply {
        set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun hour(ms: Long) = cal(ms).get(Calendar.HOUR_OF_DAY)
    fun minute(ms: Long) = cal(ms).get(Calendar.MINUTE)
    fun dayOfMonth(ms: Long) = cal(ms).get(Calendar.DAY_OF_MONTH)

    /** Next time after [after] for a repeating item starting at [ms]. */
    fun nextRepeat(ms: Long, repeat: Int, after: Long = now()): Long {
        if (repeat == 0) return ms
        var t = ms
        var guard = 0
        while (t <= after && guard < 5000) {
            t = when (repeat) {
                1 -> addDays(t, 1)
                2 -> addDays(t, 7)
                else -> addMonths(t, 1)
            }
            guard++
        }
        return t
    }

    /** Next ring time of an alarm. [days] is a bit mask (bit 0 = Sunday). */
    fun nextAlarm(hour: Int, minute: Int, days: Int, from: Long = now()): Long {
        for (i in 0..7) {
            val t = withTime(addDays(from, i), hour, minute)
            if (t > from) {
                if (days == 0) return t
                val dow = cal(t).get(Calendar.DAY_OF_WEEK) - 1
                if ((days and (1 shl dow)) != 0) return t
            }
        }
        return withTime(addDays(from, 1), hour, minute)
    }

    // Date picker works in UTC midnight, convert to / from local dates.
    fun localToUtcDay(ms: Long): Long {
        val c = cal(ms)
        val u = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        u.clear()
        u.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
        return u.timeInMillis
    }

    fun utcDayToLocal(utc: Long, base: Long): Long {
        val u = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = utc }
        return cal(base).apply {
            set(u.get(Calendar.YEAR), u.get(Calendar.MONTH), u.get(Calendar.DAY_OF_MONTH))
        }.timeInMillis
    }

    private fun fmt(ms: Long, pattern: String): String =
        SimpleDateFormat(pattern, Locale.getDefault()).format(Date(ms))

    fun date(ms: Long) = fmt(ms, "EEE, d MMM yyyy")
    fun dayTitle(ms: Long) = fmt(ms, "EEEE, d MMMM yyyy")
    fun monthTitle(ms: Long) = fmt(ms, "MMMM yyyy")
    fun shortDay(ms: Long) = fmt(ms, "EEE, d MMM")
    fun time(ms: Long): String = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(ms))
    fun full(ms: Long) = date(ms) + " · " + time(ms)
    fun hm(h: Int, m: Int) = time(withTime(now(), h, m))
    fun hourLabel(h: Int) = time(withTime(now(), h, 0))
    fun dayNumber(ms: Long) = fmt(ms, "d")

    /** dow0: 0 = Sunday ... 6 = Saturday */
    fun weekdayShort(dow0: Int): String = DateFormatSymbols.getInstance().shortWeekdays[dow0 + 1]

    fun weekdayOf(ms: Long): Int = cal(ms).get(Calendar.DAY_OF_WEEK) - 1

    /** Start of the week (locale first day) that contains [ms]. */
    fun weekStart(ms: Long): Long {
        val c = cal(startOfDay(ms))
        val diff = (c.get(Calendar.DAY_OF_WEEK) - c.firstDayOfWeek + 7) % 7
        return addDays(c.timeInMillis, -diff)
    }

    /** Weekday indexes (0 = Sunday) ordered from the locale's first day of the week. */
    fun weekOrder(): List<Int> {
        val first = Calendar.getInstance().firstDayOfWeek - 1
        return (0..6).map { (first + it) % 7 }
    }

    /** Cells of a month grid; null = empty cell. Length is a multiple of 7. */
    fun monthGrid(ms: Long): List<Long?> {
        val c = cal(startOfDay(ms)).apply { set(Calendar.DAY_OF_MONTH, 1) }
        val offset = (c.get(Calendar.DAY_OF_WEEK) - c.firstDayOfWeek + 7) % 7
        val days = c.getActualMaximum(Calendar.DAY_OF_MONTH)
        val list = ArrayList<Long?>()
        repeat(offset) { list.add(null) }
        for (d in 0 until days) list.add(addDays(c.timeInMillis, d))
        while (list.size % 7 != 0) list.add(null)
        return list
    }
}
