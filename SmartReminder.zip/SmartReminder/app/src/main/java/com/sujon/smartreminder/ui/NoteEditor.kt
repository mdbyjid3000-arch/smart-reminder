package com.sujon.smartreminder.ui

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Checklist
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Unarchive
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.sujon.smartreminder.AppViewModel
import com.sujon.smartreminder.R
import com.sujon.smartreminder.data.CheckItem
import com.sujon.smartreminder.data.Note
import com.sujon.smartreminder.data.encodeChecklist
import com.sujon.smartreminder.data.parseChecklist
import com.sujon.smartreminder.util.VoicePlayer
import com.sujon.smartreminder.util.VoiceRecorder
import com.sujon.smartreminder.util.AppFlags
import kotlinx.coroutines.delay
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditor(vm: AppViewModel, nav: NavController, noteId: Long) {
    val ctx = LocalContext.current
    val allNotes by vm.notes.collectAsStateWithLifecycle()
    val existing = remember(noteId) { allNotes.firstOrNull { it.id == noteId } }

    var title by remember { mutableStateOf(existing?.title ?: "") }
    var body by remember { mutableStateOf(existing?.body ?: "") }
    var color by remember { mutableIntStateOf(existing?.color ?: 0) }
    var pinned by remember { mutableStateOf(existing?.pinned ?: false) }
    var archived by remember { mutableStateOf(existing?.archived ?: false) }
    var isChecklist by remember { mutableStateOf(existing?.isChecklist ?: false) }
    var audioPath by remember { mutableStateOf(existing?.audioPath ?: "") }
    val items = remember {
        mutableStateListOf<CheckItem>().apply { addAll(parseChecklist(existing?.checklist ?: "")) }
    }
    var confirmDelete by remember { mutableStateOf(false) }

    // ---- voice note ----
    val recorder = remember { VoiceRecorder(ctx) }
    val player = remember { VoicePlayer() }
    var recording by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var seconds by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        onDispose {
            recorder.release()
            player.stop()
        }
    }
    LaunchedEffect(recording) {
        seconds = 0
        while (recording) {
            delay(1000)
            seconds++
        }
    }
    fun startRecording() {
        if (audioPath.isNotEmpty()) File(audioPath).delete()
        audioPath = ""
        if (recorder.start()) recording = true
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecording()
    }

    fun buildNote(): Note = Note(
        id = existing?.id ?: noteId,
        title = title.trim(),
        body = body,
        color = color,
        pinned = pinned,
        archived = archived,
        isChecklist = isChecklist,
        checklist = encodeChecklist(items.filter { it.text.isNotBlank() }),
        audioPath = audioPath
    )

    fun isEmpty(): Boolean =
        title.isBlank() && body.isBlank() && items.none { it.text.isNotBlank() } && audioPath.isEmpty()

    fun saveAndExit() {
        // The note list had not finished loading – leave without touching anything.
        if (noteId != 0L && existing == null) {
            nav.popBackStack()
            return
        }
        if (recording) {
            recorder.stop()?.let { audioPath = it.absolutePath }
            recording = false
        }
        player.stop()
        if (!isEmpty()) vm.saveNote(buildNote())
        else if (existing != null) vm.deleteNote(existing)
        nav.popBackStack()
    }

    BackHandler { saveAndExit() }

    val bg = noteColor(color)

    Scaffold(
        containerColor = bg,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = bg),
                title = {},
                navigationIcon = {
                    IconButton(onClick = { saveAndExit() }) {
                        Icon(Icons.Rounded.Check, stringResource(R.string.save))
                    }
                },
                actions = {
                    IconButton(onClick = { pinned = !pinned }) {
                        Icon(
                            Icons.Rounded.PushPin, stringResource(R.string.pin),
                            tint = if (pinned) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { archived = !archived }) {
                        Icon(
                            if (archived) Icons.Rounded.Unarchive else Icons.Rounded.Archive,
                            stringResource(R.string.archive)
                        )
                    }
                    if (existing != null) {
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Rounded.Delete, stringResource(R.string.delete))
                        }
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .imePadding()
                .navigationBarsPadding()
        ) {
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp)
            ) {
                val fieldColors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                )
                TextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text(stringResource(R.string.title), style = MaterialTheme.typography.titleLarge) },
                    textStyle = MaterialTheme.typography.titleLarge,
                    colors = fieldColors,
                    modifier = Modifier.fillMaxWidth()
                )
                if (isChecklist) {
                    items.forEachIndexed { index, item ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = item.checked,
                                onCheckedChange = { items[index] = item.copy(checked = it) }
                            )
                            TextField(
                                value = item.text,
                                onValueChange = { items[index] = item.copy(text = it.replace("\n", " ")) },
                                textStyle = MaterialTheme.typography.bodyLarge.copy(
                                    textDecoration = if (item.checked) TextDecoration.LineThrough else null
                                ),
                                colors = fieldColors,
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { items.removeAt(index) }) {
                                Icon(Icons.Rounded.Close, null)
                            }
                        }
                    }
                    TextButton(onClick = { items.add(CheckItem(false, "")) }) {
                        Icon(Icons.Rounded.Add, null)
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.add_item))
                    }
                } else {
                    TextField(
                        value = body,
                        onValueChange = { body = it },
                        placeholder = { Text(stringResource(R.string.write_note)) },
                        colors = fieldColors,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                    )
                }

                // Voice note
                if (recording || audioPath.isNotEmpty()) {
                    Row(
                        Modifier
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (recording) {
                            Text(
                                stringResource(R.string.recording) + "  %d:%02d".format(seconds / 60, seconds % 60),
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedButton(onClick = {
                                recorder.stop()?.let { audioPath = it.absolutePath }
                                recording = false
                            }) {
                                Icon(Icons.Rounded.Stop, null)
                                Spacer(Modifier.width(6.dp))
                                Text(stringResource(R.string.stop))
                            }
                        } else {
                            Icon(Icons.Rounded.Mic, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.voice_note), Modifier.weight(1f))
                            OutlinedButton(onClick = {
                                if (playing) {
                                    player.stop()
                                    playing = false
                                } else {
                                    playing = player.play(audioPath) { playing = false }
                                }
                            }) {
                                Icon(if (playing) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, null)
                            }
                            IconButton(onClick = {
                                player.stop()
                                playing = false
                                File(audioPath).delete()
                                audioPath = ""
                            }) { Icon(Icons.Rounded.Delete, stringResource(R.string.delete)) }
                        }
                    }
                }
            }

            // Bottom tool bar: colours, checklist toggle, mic
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    if (!isChecklist) {
                        if (items.isEmpty() && body.isNotBlank()) {
                            body.lines().filter { it.isNotBlank() }.forEach { items.add(CheckItem(false, it)) }
                            body = ""
                        } else if (items.isEmpty()) {
                            items.add(CheckItem(false, ""))
                        }
                    } else {
                        if (body.isBlank()) body = items.joinToString("\n") { it.text }
                    }
                    isChecklist = !isChecklist
                }) {
                    Icon(
                        Icons.Rounded.Checklist, stringResource(R.string.checklist),
                        tint = if (isChecklist) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = {
                    if (recording) return@IconButton
                    AppFlags.skipLock = true
                    micPermission.launch(Manifest.permission.RECORD_AUDIO)
                }) {
                    Icon(Icons.Rounded.Mic, stringResource(R.string.voice_note))
                }
                Spacer(Modifier.width(8.dp))
                Row(
                    Modifier.weight(1f).padding(start = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (i in 0 until NOTE_COLOR_COUNT) {
                        Box(
                            Modifier
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(noteColor(i))
                                .border(
                                    if (i == color) 2.dp else 1.dp,
                                    if (i == color) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.outline,
                                    CircleShape
                                )
                                .clickable { color = i }
                        )
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            text = stringResource(R.string.confirm_delete_note),
            onConfirm = {
                confirmDelete = false
                player.stop()
                existing?.let { vm.deleteNote(it) }
                nav.popBackStack()
            },
            onDismiss = { confirmDelete = false }
        )
    }
}
