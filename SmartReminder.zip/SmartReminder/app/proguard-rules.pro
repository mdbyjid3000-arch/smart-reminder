# Debug build only – no rules needed.
